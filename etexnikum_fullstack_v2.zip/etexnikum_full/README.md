# eTexnikum — full stack

Это объединённая версия eTexnikum: главная страница → `Kirish` → логин → личный кабинет.
Frontend больше не хранит пользователей, пароли, оценки, сообщения или файлы в `localStorage`.

## Что изменено

- FastAPI + SQLAlchemy 2 + SQLite (готово к переходу на PostgreSQL).
- Пароли хранятся только в PBKDF2-SHA256 hash.
- Сессия — подписанный HttpOnly cookie, а не `localStorage`.
- Язык UZ/RU/EN единый для главной, логина и кабинета.
- Директор: в журнале входов видит только `curator` и `teacher` своего техникума.
- Учитель: видит только студентов своей группы и свои рабочие разделы.
- Админ: отдельное админ-меню; админские функции не показываются обычным ролям.
- Профиль: подтверждаемая привязка email и телефона.
- Восстановление пароля: email или SMS. SMTP/Twilio подключаются через `.env`.
- Файлы чата сохраняются на сервере, а не в base64/localStorage. Лимит задаётся `MAX_UPLOAD_MB` (по умолчанию 20 MB).
- Резервная копия SQLite через `POST /api/admin/backup` и `backend/backup.py`.
- Все тексты интерфейса вынесены в один словарь на три языка, поэтому меню и логин не расходятся.
- Иконки — SVG, без emoji.

## Запуск

```bash
cd backend
cp .env.example .env
# обязательно поменяйте SECRET_KEY и ADMIN_PASSWORD
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

Открыть: `http://127.0.0.1:8000`

Первый администратор создаётся автоматически из `.env`:

- `ADMIN_LOGIN`
- `ADMIN_PASSWORD`
- `ADMIN_NAME`

После первого запуска пароль администратора рекомендуется сразу изменить.

## Docker

```bash
cp backend/.env.example backend/.env
# отредактируйте backend/.env
docker compose up --build
```

## Email / SMS

Без SMTP/Twilio приложение работает в dev-режиме: код восстановления/подтверждения выводится в лог сервера, но не отдаётся браузеру.

Для production заполните SMTP-переменные и/или Twilio. Для Twilio добавьте в requirements:

```text
twilio
```

и задайте `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`.

## Важное по безопасности

Для production:

1. Используйте HTTPS.
2. Поставьте `COOKIE_SECURE=true`.
3. Задайте длинный случайный `SECRET_KEY`.
4. Используйте PostgreSQL вместо SQLite при высокой нагрузке.
5. Храните `uploads/` и `backups/` вне публичной директории.
6. Настройте регулярный внешний backup. Локальная backup-команда не заменяет полноценную стратегию резервного копирования.
