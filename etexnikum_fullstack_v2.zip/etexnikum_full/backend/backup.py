import asyncio
import os
import shutil
from datetime import datetime
from pathlib import Path
from config import settings


async def make_backup():
    Path(settings.backup_dir).mkdir(parents=True, exist_ok=True)
    # SQLite file is copied for this deployment. For PostgreSQL, use pg_dump instead.
    db_path = Path("./etexnikum.db")
    if not db_path.exists():
        return None
    name = f"etexnikum-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}.db"
    target = Path(settings.backup_dir) / name
    shutil.copy2(db_path, target)
    return str(target)


if __name__ == "__main__":
    print(asyncio.run(make_backup()))
