from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "eTexnikum"
    secret_key: str = "change-me"
    database_url: str = "sqlite+aiosqlite:///./etexnikum.db"
    upload_dir: str = "../uploads"
    backup_dir: str = "../backups"
    max_upload_mb: int = 20
    session_days: int = 7
    cookie_secure: bool = False

    admin_login: str = "admin"
    admin_password: str = "ChangeMe_12345"
    admin_name: str = "eTexnikum Admin"

    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_tls: bool = True

    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_from: str = ""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


settings = Settings()
