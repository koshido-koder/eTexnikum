from __future__ import annotations

import hashlib
import os
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backup import make_backup
from config import settings
from db import Base, SessionLocal, engine, init_db
from models import (
    Announcement, Attendance, ChatMessage, College, Grade, Group, Homework,
    LoginLog, ResetToken, User,
)
from notify import send_email, send_sms
from security import decode_session, hash_password, make_reset_token, make_session, verify_password

BASE = Path(__file__).resolve().parent
FRONTEND = BASE.parent / "frontend"
UPLOAD_DIR = (BASE / settings.upload_dir).resolve()
BACKUP_DIR = (BASE / settings.backup_dir).resolve()
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title=settings.app_name, version="2.0.0")
app.mount("/static", StaticFiles(directory=FRONTEND), name="static")


class LoginIn(BaseModel):
    login: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=200)


class ProfileIn(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=160)
    email: EmailStr | None = None
    phone: str | None = Field(default=None, max_length=32)
    language: str | None = Field(default=None, pattern="^(uz|ru|en)$")


class PasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=200)


class ResetRequestIn(BaseModel):
    login: str = Field(min_length=1, max_length=80)
    channel: str = Field(pattern="^(email|sms)$")


class ResetConfirmIn(BaseModel):
    token: str
    new_password: str = Field(min_length=8, max_length=200)


class ContactStartIn(BaseModel):
    channel: str = Field(pattern="^(email|sms)$")
    value: str = Field(min_length=3, max_length=320)


class ContactConfirmIn(BaseModel):
    channel: str = Field(pattern="^(email|sms)$")
    value: str = Field(min_length=3, max_length=320)
    code: str = Field(min_length=6, max_length=6)


class CollegeIn(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    city: str = Field(default="", max_length=100)


class UserIn(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    login: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=8, max_length=200)
    role: str = Field(pattern="^(director|curator|teacher|student)$")
    group_id: int | None = None
    subject: str = Field(default="", max_length=160)


class GroupIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class AttendanceIn(BaseModel):
    student_id: int
    date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    status: str = Field(pattern="^[pal]$")


class GradeIn(BaseModel):
    student_id: int
    value: int = Field(ge=2, le=5)
    comment: str = Field(default="", max_length=500)


class ReportIn(BaseModel):
    recipient_role: str = Field(pattern="^(director|deputy)$")
    text: str = Field(min_length=1, max_length=5000)


class AnnouncementIn(BaseModel):
    text: str = Field(min_length=1, max_length=5000)


class HomeworkIn(BaseModel):
    group_id: int
    text: str = Field(min_length=1, max_length=5000)
    due_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")


async def db():
    async with SessionLocal() as session:
        yield session


def client_ip(request: Request) -> str:
    return request.client.host if request.client else ""


def role_is(user: User, *roles: str) -> bool:
    return user.role in roles


async def current_user(request: Request, session: AsyncSession = Depends(db)) -> User:
    token = request.cookies.get("et_session")
    user_id = decode_session(token) if token else None
    if not user_id:
        raise HTTPException(401, "AUTH_REQUIRED")
    user = await session.get(User, user_id)
    if not user or user.blocked:
        raise HTTPException(401, "AUTH_REQUIRED")
    if user.college_id:
        college = await session.get(College, user.college_id)
        if college and college.blocked:
            raise HTTPException(403, "COLLEGE_BLOCKED")
    return user


async def require_roles(user: User, *roles: str):
    if user.role not in roles:
        raise HTTPException(403, "FORBIDDEN")


def user_json(u: User) -> dict:
    return {
        "id": u.id, "name": u.name, "login": u.login, "role": u.role,
        "college_id": u.college_id, "group_id": u.group_id, "subject": u.subject,
        "email": u.email, "phone": u.phone, "language": u.language,
        "must_change_password": u.must_change_password,
    }


async def seed():
    async with SessionLocal() as s:
        q = await s.execute(select(User).where(User.login == settings.admin_login))
        if q.scalar_one_or_none():
            return
        admin = User(
            name=settings.admin_name,
            login=settings.admin_login,
            password_hash=hash_password(settings.admin_password),
            role="admin",
            language="ru",
        )
        s.add(admin)
        await s.commit()


@app.on_event("startup")
async def startup():
    await init_db()
    await seed()


@app.get("/")
async def index():
    return FileResponse(FRONTEND / "index.html")


@app.get("/api/session")
async def session_info(request: Request, session: AsyncSession = Depends(db)):
    token = request.cookies.get("et_session")
    uid = decode_session(token) if token else None
    if not uid:
        return {"authenticated": False, "language": request.cookies.get("et_lang", "ru")}
    user = await session.get(User, uid)
    if not user or user.blocked:
        return {"authenticated": False, "language": request.cookies.get("et_lang", "ru")}
    return {"authenticated": True, "user": user_json(user), "language": user.language}


@app.post("/api/language")
async def language(request: Request, session: AsyncSession = Depends(db)):
    data = await request.json()
    lang = data.get("language", "ru")
    if lang not in {"uz", "ru", "en"}:
        raise HTTPException(400, "BAD_LANGUAGE")
    response = {"ok": True, "language": lang}
    request.state.language = lang
    # Cookie is intentionally used only for UI language; no application state is stored in the browser.
    from fastapi.responses import JSONResponse
    r = JSONResponse(response)
    r.set_cookie("et_lang", lang, max_age=31536000, samesite="lax", secure=settings.cookie_secure)
    token = request.cookies.get("et_session")
    uid = decode_session(token) if token else None
    if uid:
        user = await session.get(User, uid)
        if user:
            user.language = lang
            await session.commit()
    return r


@app.post("/api/login")
async def login(payload: LoginIn, request: Request, session: AsyncSession = Depends(db)):
    login_value = payload.login.strip().lower()
    result = await session.execute(select(User).where(func.lower(User.login) == login_value))
    user = result.scalar_one_or_none()
    ok = bool(user and verify_password(payload.password, user.password_hash) and not user.blocked)
    if user and user.college_id:
        college = await session.get(College, user.college_id)
        ok = ok and not (college and college.blocked)
    session.add(LoginLog(user_id=user.id if user else None, login=login_value, role=user.role if user else "unknown", success=ok, ip=client_ip(request)))
    await session.commit()
    if not ok:
        raise HTTPException(401, "BAD_CREDENTIALS")
    response_data = {"ok": True, "user": user_json(user)}
    from fastapi.responses import JSONResponse
    response = JSONResponse(response_data)
    response.set_cookie("et_session", make_session(user.id), httponly=True, max_age=settings.session_days * 86400, samesite="lax", secure=settings.cookie_secure)
    response.set_cookie("et_lang", user.language or "ru", max_age=31536000, samesite="lax", secure=settings.cookie_secure)
    return response


@app.post("/api/logout")
async def logout():
    from fastapi.responses import JSONResponse
    r = JSONResponse({"ok": True})
    r.delete_cookie("et_session")
    return r


@app.get("/api/state")
async def state(user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if role_is(user, "admin"):
        colleges = (await session.execute(select(College).order_by(College.name))).scalars().all()
        users = (await session.execute(select(User).order_by(User.name))).scalars().all()
        return {"role": user.role, "colleges": [{"id": c.id, "name": c.name, "city": c.city, "blocked": c.blocked} for c in colleges], "users": [user_json(x) for x in users]}

    if not user.college_id:
        return {"role": user.role, "groups": [], "users": []}

    groups = (await session.execute(select(Group).where(Group.college_id == user.college_id).order_by(Group.name))).scalars().all()
    if role_is(user, "director"):
        users = (await session.execute(select(User).where(User.college_id == user.college_id, User.role.in_(["director", "curator", "teacher"])).order_by(User.name))).scalars().all()
    elif role_is(user, "teacher"):
        users = (await session.execute(select(User).where(User.college_id == user.college_id, User.role == "student", User.group_id == user.group_id).order_by(User.name))).scalars().all()
    elif role_is(user, "curator"):
        users = (await session.execute(select(User).where(User.college_id == user.college_id, User.role == "student", User.group_id == user.group_id).order_by(User.name))).scalars().all()
    else:
        users = []
    return {"role": user.role, "groups": [{"id": g.id, "name": g.name} for g in groups], "users": [user_json(x) for x in users]}


@app.get("/api/logs")
async def logs(user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "admin", "director")
    q = select(LoginLog).order_by(desc(LoginLog.created_at)).limit(300)
    if user.role == "director":
        q = q.where(LoginLog.role.in_(["curator", "teacher"]))
        # A director may only see logs belonging to their college.
        q = q.join(User, LoginLog.user_id == User.id).where(User.college_id == user.college_id)
    rows = (await session.execute(q)).scalars().all()
    return [{"login": x.login, "role": x.role, "success": x.success, "ip": x.ip, "created_at": x.created_at.isoformat()} for x in rows]


@app.post("/api/colleges")
async def create_college(payload: CollegeIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "admin")
    c = College(name=payload.name.strip(), city=payload.city.strip())
    session.add(c)
    await session.commit()
    return {"id": c.id}


@app.post("/api/groups")
async def create_group(payload: GroupIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "director")
    g = Group(name=payload.name.strip(), college_id=user.college_id)
    session.add(g)
    await session.commit()
    return {"id": g.id}


@app.post("/api/users")
async def create_user(payload: UserIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "admin", "director")
    if payload.role == "student" and user.role != "director":
        raise HTTPException(403, "FORBIDDEN")
    if user.role == "director" and payload.role not in {"curator", "teacher", "student"}:
        raise HTTPException(403, "FORBIDDEN")
    exists = await session.execute(select(User).where(func.lower(User.login) == payload.login.lower()))
    if exists.scalar_one_or_none():
        raise HTTPException(409, "LOGIN_TAKEN")
    college_id = user.college_id if user.role == "director" else None
    if user.role == "admin":
        college_id = None
    u = User(name=payload.name.strip(), login=payload.login.strip(), password_hash=hash_password(payload.password), role=payload.role, college_id=college_id, group_id=payload.group_id, subject=payload.subject.strip(), language=user.language, must_change_password=True)
    session.add(u)
    await session.commit()
    return user_json(u)


@app.post("/api/attendance")
async def set_attendance(payload: AttendanceIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "director", "curator", "teacher")
    student = await session.get(User, payload.student_id)
    if not student or student.role != "student" or student.college_id != user.college_id:
        raise HTTPException(404, "STUDENT_NOT_FOUND")
    if user.role in {"curator", "teacher"} and student.group_id != user.group_id:
        raise HTTPException(403, "FORBIDDEN")
    q = await session.execute(select(Attendance).where(Attendance.student_id == student.id, Attendance.date == payload.date))
    row = q.scalar_one_or_none()
    if row:
        row.status = payload.status
        row.marked_by = user.id
    else:
        session.add(Attendance(student_id=student.id, date=payload.date, status=payload.status, marked_by=user.id))
    await session.commit()
    return {"ok": True}


@app.get("/api/attendance")
async def get_attendance(user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if role_is(user, "student"):
        ids = [user.id]
    elif role_is(user, "teacher", "curator"):
        ids = [x.id for x in (await session.execute(select(User.id).where(User.college_id == user.college_id, User.role == "student", User.group_id == user.group_id))).all()]
    else:
        ids = [x.id for x in (await session.execute(select(User.id).where(User.college_id == user.college_id, User.role == "student"))).all()]
    if not ids:
        return []
    rows = (await session.execute(select(Attendance).where(Attendance.student_id.in_(ids)).order_by(desc(Attendance.date)))).scalars().all()
    return [{"student_id": x.student_id, "date": x.date, "status": x.status} for x in rows]


@app.post("/api/grades")
async def add_grade(payload: GradeIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "teacher")
    student = await session.get(User, payload.student_id)
    if not student or student.role != "student" or student.college_id != user.college_id or student.group_id != user.group_id:
        raise HTTPException(403, "FORBIDDEN")
    g = Grade(student_id=student.id, teacher_id=user.id, subject=user.subject or "—", value=payload.value, comment=payload.comment, date=datetime.now().date().isoformat())
    session.add(g)
    await session.commit()
    return {"ok": True}


@app.get("/api/grades")
async def get_grades(user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if user.role == "student":
        q = select(Grade).where(Grade.student_id == user.id)
    elif user.role == "teacher":
        q = select(Grade).where(Grade.teacher_id == user.id)
    else:
        return []
    rows = (await session.execute(q.order_by(desc(Grade.date)))).scalars().all()
    return [{"student_id": x.student_id, "teacher_id": x.teacher_id, "subject": x.subject, "value": x.value, "comment": x.comment, "date": x.date} for x in rows]


@app.post("/api/reports")
async def add_report(payload: ReportIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if user.role not in {"teacher", "curator", "director"}:
        raise HTTPException(403, "FORBIDDEN")
    r = Report(college_id=user.college_id, author_id=user.id, recipient_role=payload.recipient_role, text=payload.text.strip())
    session.add(r)
    await session.commit()
    return {"ok": True}


@app.get("/api/reports")
async def get_reports(user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if user.role == "director":
        q = select(Report, User).join(User, Report.author_id == User.id).where(Report.college_id == user.college_id)
    else:
        q = select(Report, User).join(User, Report.author_id == User.id).where(Report.author_id == user.id)
    rows = (await session.execute(q.order_by(desc(Report.created_at)))).all()
    return [{"author": u.name, "role": u.role, "recipient_role": r.recipient_role, "text": r.text, "created_at": r.created_at.isoformat()} for r, u in rows]


@app.post("/api/announcements")
async def add_announcement(payload: AnnouncementIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "director")
    a = Announcement(college_id=user.college_id, author_id=user.id, text=payload.text.strip())
    session.add(a)
    await session.commit()
    return {"ok": True}


@app.get("/api/announcements")
async def announcements(user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if not user.college_id:
        return []
    rows = (await session.execute(select(Announcement, User).join(User, Announcement.author_id == User.id).where(Announcement.college_id == user.college_id).order_by(desc(Announcement.created_at)))).all()
    return [{"author": u.name, "text": a.text, "created_at": a.created_at.isoformat()} for a, u in rows]


@app.post("/api/homework")
async def add_homework(payload: HomeworkIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    await require_roles(user, "teacher")
    g = await session.get(Group, payload.group_id)
    if not g or g.college_id != user.college_id or g.id != user.group_id:
        raise HTTPException(403, "FORBIDDEN")
    h = Homework(college_id=user.college_id, group_id=g.id, teacher_id=user.id, subject=user.subject or "—", text=payload.text.strip(), due_date=payload.due_date)
    session.add(h)
    await session.commit()
    return {"ok": True}


@app.get("/api/homework")
async def get_homework(user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if user.role == "student":
        q = select(Homework, User).join(User, Homework.teacher_id == User.id).where(Homework.group_id == user.group_id)
    elif user.role == "teacher":
        q = select(Homework, User).join(User, Homework.teacher_id == User.id).where(Homework.teacher_id == user.id)
    else:
        return []
    rows = (await session.execute(q.order_by(desc(Homework.created_at)))).all()
    return [{"teacher": u.name, "subject": h.subject, "text": h.text, "due_date": h.due_date, "created_at": h.created_at.isoformat()} for h, u in rows]


@app.get("/api/chat/{room}")
async def get_chat(room: str, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    allowed = {"general"}
    if user.role == "director": allowed |= {"curators", "teachers"}
    if user.role == "teacher": allowed |= {"students"}
    if user.role == "curator": allowed |= {"students"}
    if room.startswith("group-"): allowed.add(room)
    if room not in allowed:
        raise HTTPException(403, "FORBIDDEN")
    rows = (await session.execute(select(ChatMessage, User).join(User, ChatMessage.author_id == User.id).where(ChatMessage.college_id == user.college_id, ChatMessage.room == room).order_by(ChatMessage.created_at).limit(300))).all()
    return [{"id": m.id, "author": u.name, "role": u.role, "text": m.text, "file_name": m.file_name, "file_url": f"/api/files/{m.file_path}" if m.file_path else None, "created_at": m.created_at.isoformat()} for m, u in rows]


@app.post("/api/chat/{room}")
async def post_chat(room: str, request: Request, text: str = "", file: UploadFile | None = File(default=None), user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if room not in {"general", "curators", "teachers", "students"} and not room.startswith("group-"):
        raise HTTPException(403, "FORBIDDEN")
    if user.role == "student" and room not in {"general", "students"} and not room.startswith("group-"):
        raise HTTPException(403, "FORBIDDEN")
    file_name = file_path = None
    if file:
        max_bytes = settings.max_upload_mb * 1024 * 1024
        content = await file.read(max_bytes + 1)
        if len(content) > max_bytes:
            raise HTTPException(413, "FILE_TOO_LARGE")
        safe = Path(file.filename or "file").name
        suffix = Path(safe).suffix[:12]
        stored = f"{secrets.token_hex(16)}{suffix}"
        target = UPLOAD_DIR / stored
        target.write_bytes(content)
        file_name, file_path = safe, stored
    m = ChatMessage(college_id=user.college_id, room=room, author_id=user.id, text=text.strip(), file_name=file_name, file_path=file_path)
    session.add(m)
    await session.commit()
    return {"ok": True}


@app.get("/api/files/{name}")
async def file_download(name: str, user: User = Depends(current_user)):
    safe = Path(name).name
    p = UPLOAD_DIR / safe
    if not p.exists():
        raise HTTPException(404, "FILE_NOT_FOUND")
    return FileResponse(p)


@app.patch("/api/profile")
async def profile(payload: ProfileIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if payload.name is not None:
        user.name = payload.name.strip()
    if payload.email is not None:
        user.email = str(payload.email).lower()
    if payload.phone is not None:
        user.phone = payload.phone.strip()
    if payload.language is not None:
        user.language = payload.language
    await session.commit()
    return user_json(user)


@app.post("/api/profile/contact/start")
async def contact_start(payload: ContactStartIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if payload.channel == "email":
        target = payload.value.lower()
    else:
        target = payload.value.strip()
    code = f"{secrets.randbelow(1_000_000):06d}"
    _, token_hash = make_reset_token()
    # The code is hashed into the same table; raw code is delivered only out-of-band.
    code_hash = hashlib.sha256(code.encode()).hexdigest()
    row = ResetToken(user_id=user.id, channel=f"bind_{payload.channel}", token_hash=code_hash, expires_at=datetime.now(timezone.utc) + timedelta(minutes=10))
    session.add(row)
    await session.commit()
    message = f"eTexnikum verification code: {code}. It expires in 10 minutes."
    if payload.channel == "email":
        await send_email(target, "eTexnikum — verification code", message)
    else:
        await send_sms(target, message)
    return {"ok": True}


@app.post("/api/profile/contact/confirm")
async def contact_confirm(payload: ContactConfirmIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    h = hashlib.sha256(payload.code.encode()).hexdigest()
    q = await session.execute(select(ResetToken).where(ResetToken.user_id == user.id, ResetToken.channel == f"bind_{payload.channel}", ResetToken.token_hash == h, ResetToken.used.is_(False)).order_by(desc(ResetToken.id)))
    row = q.scalars().first()
    if not row or row.expires_at < datetime.now(timezone.utc):
        raise HTTPException(400, "BAD_CODE")
    row.used = True
    if payload.channel == "email":
        user.email = payload.value.lower()
    else:
        user.phone = payload.value.strip()
    await session.commit()
    return user_json(user)


@app.post("/api/profile/password")
async def change_password(payload: PasswordIn, user: User = Depends(current_user), session: AsyncSession = Depends(db)):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(400, "BAD_PASSWORD")
    user.password_hash = hash_password(payload.new_password)
    user.must_change_password = False
    await session.commit()
    return {"ok": True}


@app.post("/api/password-reset/request")
async def reset_request(payload: ResetRequestIn, session: AsyncSession = Depends(db)):
    q = await session.execute(select(User).where(func.lower(User.login) == payload.login.strip().lower()))
    user = q.scalar_one_or_none()
    # Same response for missing account, so the endpoint does not disclose whether a login exists.
    if not user:
        return {"ok": True}
    target = user.email if payload.channel == "email" else user.phone
    if not target:
        return {"ok": True, "contact_missing": True}
    raw, hashed = make_reset_token()
    row = ResetToken(user_id=user.id, channel=payload.channel, token_hash=hashed, expires_at=datetime.now(timezone.utc) + timedelta(minutes=15))
    session.add(row)
    await session.commit()
    if payload.channel == "email":
        await send_email(target, "eTexnikum — password reset", f"Use this reset token in the eTexnikum password reset form:\n\n{raw}\n\nIt expires in 15 minutes.")
    else:
        await send_sms(target, f"eTexnikum reset token: {raw}. Expires in 15 minutes.")
    return {"ok": True}


@app.post("/api/password-reset/confirm")
async def reset_confirm(payload: ResetConfirmIn, session: AsyncSession = Depends(db)):
    hashed = hashlib.sha256(payload.token.encode()).hexdigest()
    q = await session.execute(select(ResetToken).where(ResetToken.channel.in_(["email", "sms"]), ResetToken.token_hash == hashed, ResetToken.used.is_(False)).order_by(desc(ResetToken.id)))
    row = q.scalars().first()
    if not row or row.expires_at < datetime.now(timezone.utc):
        raise HTTPException(400, "BAD_TOKEN")
    user = await session.get(User, row.user_id)
    if not user:
        raise HTTPException(400, "BAD_TOKEN")
    user.password_hash = hash_password(payload.new_password)
    user.must_change_password = False
    row.used = True
    await session.commit()
    return {"ok": True}


@app.post("/api/admin/backup")
async def backup_endpoint(user: User = Depends(current_user)):
    await require_roles(user, "admin")
    path = await make_backup()
    if not path:
        raise HTTPException(500, "DATABASE_FILE_NOT_FOUND")
    return {"ok": True, "file": os.path.basename(path)}
