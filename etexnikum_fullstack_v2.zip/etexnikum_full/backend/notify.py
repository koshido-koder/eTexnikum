import asyncio
import smtplib
from email.message import EmailMessage
from config import settings


async def send_email(to: str, subject: str, body: str):
    if not settings.smtp_host or not settings.smtp_from:
        print(f"[DEV EMAIL] to={to} subject={subject}\n{body}")
        return

    def _send():
        msg = EmailMessage()
        msg["From"] = settings.smtp_from
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(body)
        with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as smtp:
            if settings.smtp_tls:
                smtp.starttls()
            if settings.smtp_user:
                smtp.login(settings.smtp_user, settings.smtp_password)
            smtp.send_message(msg)

    await asyncio.to_thread(_send)


async def send_sms(to: str, body: str):
    # Twilio is intentionally optional. If not configured, the code is printed
    # to the server log instead of exposing it to the browser.
    if not all([settings.twilio_account_sid, settings.twilio_auth_token, settings.twilio_from]):
        print(f"[DEV SMS] to={to}\n{body}")
        return
    try:
        from twilio.rest import Client
    except ImportError:
        print(f"[DEV SMS] to={to}\n{body}")
        return

    def _send():
        client = Client(settings.twilio_account_sid, settings.twilio_auth_token)
        client.messages.create(body=body, from_=settings.twilio_from, to=to)

    await asyncio.to_thread(_send)
